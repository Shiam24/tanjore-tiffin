document.addEventListener('DOMContentLoaded', () => {

  /* ============================================
     FOOTER YEAR
     ============================================ */
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  /* ============================================
     MOBILE NAV TOGGLE
     ============================================ */
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', () => {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.classList.toggle('open', isOpen);
      navToggle.setAttribute('aria-expanded', isOpen);
    });

    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mainNav.classList.remove('open');
        navToggle.classList.remove('open');
        navToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  /* ============================================
     MENU TABS
     ============================================ */
  const tabButtons = document.querySelectorAll('.tab-btn');
  const panels = document.querySelectorAll('.menu-panel');

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.dataset.tab;

      tabButtons.forEach(b => {
        b.classList.toggle('active', b === btn);
        b.setAttribute('aria-selected', b === btn ? 'true' : 'false');
      });

      panels.forEach(panel => {
        panel.classList.toggle('active', panel.dataset.panel === target);
      });
    });
  });

  /* ============================================
     REVIEW CAROUSEL
     ============================================ */
  const track = document.getElementById('reviewTrack');
  const dotsWrap = document.getElementById('reviewDots');

  if (track && dotsWrap) {
    const cards = Array.from(track.children);
    let current = 0;
    let autoTimer;

    cards.forEach((_, i) => {
      const dot = document.createElement('button');
      dot.setAttribute('aria-label', `Go to review ${i + 1}`);
      if (i === 0) dot.classList.add('active');
      dot.addEventListener('click', () => goTo(i));
      dotsWrap.appendChild(dot);
    });

    const dots = Array.from(dotsWrap.children);

    function goTo(index) {
      current = (index + cards.length) % cards.length;
      track.style.transform = `translateX(-${current * 100}%)`;
      dots.forEach((d, i) => d.classList.toggle('active', i === current));
    }

    function startAuto() {
      autoTimer = setInterval(() => goTo(current + 1), 5000);
    }
    function stopAuto() {
      clearInterval(autoTimer);
    }

    track.parentElement.addEventListener('mouseenter', stopAuto);
    track.parentElement.addEventListener('mouseleave', startAuto);

    startAuto();
  }

  /* ============================================
     STICKY HEADER SHADOW ON SCROLL
     ============================================ */
  const header = document.getElementById('siteHeader');
  if (header) {
    const onScroll = () => {
      header.style.boxShadow = window.scrollY > 12
        ? '0 8px 24px -10px rgba(0,0,0,.35)'
        : 'none';
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ============================================
     KOLAM (RANGOLI) DRAWING ANIMATION
     A traditional South Indian threshold pattern:
     dots arranged in a grid, connected with looping
     curved lines, drawn fresh every morning.
     ============================================ */
  const canvas = document.getElementById('kolamCanvas');
  if (canvas && canvas.getContext) {
    const ctx = canvas.getContext('2d');
    const DPR = Math.min(window.devicePixelRatio || 1, 2);
    const SIZE = canvas.width; // logical size (420)
    canvas.width = SIZE * DPR;
    canvas.height = SIZE * DPR;
    ctx.scale(DPR, DPR);

    const GRID = 7;               // 7x7 dot grid
    const MARGIN = 50;
    const SPACING = (SIZE - MARGIN * 2) / (GRID - 1);

    // build dot positions
    const dots = [];
    for (let r = 0; r < GRID; r++) {
      for (let c = 0; c < GRID; c++) {
        dots.push({
          x: MARGIN + c * SPACING,
          y: MARGIN + r * SPACING
        });
      }
    }

    const dotAt = (r, c) => dots[r * GRID + c];

    // Generate a set of looping curved petals around diamond points,
    // mimicking a pulli (dot) kolam drawn around a grid.
    function buildPaths() {
      const paths = [];
      const mid = (GRID - 1) / 2;

      for (let r = 0; r < GRID - 1; r++) {
        for (let c = 0; c < GRID - 1; c++) {
          // skip a checker pattern for breathing room, like real kolams
          if ((r + c) % 2 !== 0) continue;

          const tl = dotAt(r, c);
          const tr = dotAt(r, c + 1);
          const bl = dotAt(r + 1, c);
          const br = dotAt(r + 1, c + 1);
          const cx = (tl.x + br.x) / 2;
          const cy = (tl.y + br.y) / 2;
          const rad = SPACING * 0.62;

          paths.push({
            type: 'loop',
            cx, cy, rad,
            start: 0,
            end: Math.PI * 2
          });
        }
      }

      // Outer connecting arcs along the border for a frame
      for (let i = 0; i < GRID - 1; i++) {
        const a = dotAt(0, i);
        const b = dotAt(0, i + 1);
        paths.push({ type: 'arc-h', x1: a.x, y1: a.y, x2: b.x, y2: b.y, dir: -1 });

        const a2 = dotAt(GRID - 1, i);
        const b2 = dotAt(GRID - 1, i + 1);
        paths.push({ type: 'arc-h', x1: a2.x, y1: a2.y, x2: b2.x, y2: b2.y, dir: 1 });

        const a3 = dotAt(i, 0);
        const b3 = dotAt(i + 1, 0);
        paths.push({ type: 'arc-v', x1: a3.x, y1: a3.y, x2: a3.x !== undefined ? a3.x : 0, y2: b3.y, dir: -1, a: a3, b: b3 });

        const a4 = dotAt(i, GRID - 1);
        const b4 = dotAt(i + 1, GRID - 1);
        paths.push({ type: 'arc-v', a: a4, b: b4, dir: 1 });
      }

      return paths;
    }

    const paths = buildPaths();
    const totalDuration = 3800; // ms for the whole drawing
    let startTime = null;
    let rafId = null;

    function drawDots(progress) {
      ctx.save();
      dots.forEach(d => {
        ctx.beginPath();
        ctx.arc(d.x, d.y, 2.6, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(217,160,44,${0.55 + 0.45 * progress})`;
        ctx.fill();
      });
      ctx.restore();
    }

    function strokePathSegment(p, t) {
      ctx.lineWidth = 3;
      ctx.lineCap = 'round';
      ctx.strokeStyle = '#F6EFDC';

      if (p.type === 'loop') {
        const sweep = (p.end - p.start) * t;
        ctx.beginPath();
        ctx.arc(p.cx, p.cy, p.rad, p.start - Math.PI / 2, p.start - Math.PI / 2 + sweep);
        ctx.stroke();
      } else if (p.type === 'arc-h') {
        const midX = (p.x1 + p.x2) / 2;
        const midY = p.y1 + p.dir * (SPACING * 0.45);
        drawQuadPartial(p.x1, p.y1, midX, midY, p.x2, p.y2, t);
      } else if (p.type === 'arc-v') {
        const midX = p.a.x + p.dir * (SPACING * 0.45);
        const midY = (p.a.y + p.b.y) / 2;
        drawQuadPartial(p.a.x, p.a.y, midX, midY, p.b.x, p.b.y, t);
      }
    }

    function drawQuadPartial(x0, y0, cx, cy, x1, y1, t) {
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      const steps = 24;
      const upTo = Math.max(1, Math.floor(steps * t));
      for (let i = 1; i <= upTo; i++) {
        const tt = i / steps;
        const xa = lerp(x0, cx, tt), ya = lerp(y0, cy, tt);
        const xb = lerp(cx, x1, tt), yb = lerp(cy, y1, tt);
        ctx.lineTo(lerp(xa, xb, tt), lerp(ya, yb, tt));
      }
      ctx.stroke();
    }

    function lerp(a, b, t) { return a + (b - a) * t; }

    function render(now) {
      if (!startTime) startTime = now;
      const elapsed = now - startTime;
      const overallT = Math.min(elapsed / totalDuration, 1);

      ctx.clearRect(0, 0, SIZE, SIZE);

      // soft maroon backdrop circle to match hero
      ctx.save();
      ctx.beginPath();
      ctx.arc(SIZE / 2, SIZE / 2, SIZE / 2 - 6, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.04)';
      ctx.fill();
      ctx.restore();

      const perPath = 1 / paths.length;
      paths.forEach((p, i) => {
        const pathStart = i * perPath * 0.85; // overlap slightly for fluidity
        const pathEnd = pathStart + perPath * 1.6;
        let localT = (overallT - pathStart) / (pathEnd - pathStart);
        localT = Math.max(0, Math.min(1, localT));
        if (localT > 0) strokePathSegment(p, localT);
      });

      drawDots(overallT);

      if (overallT < 1) {
        rafId = requestAnimationFrame(render);
      }
    }

    // Respect reduced motion preference: draw the final frame instantly
    const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) {
      paths.forEach(p => strokePathSegment(p, 1));
      drawDots(1);
    } else {
      rafId = requestAnimationFrame(render);

      // Redraw on resize (keeps it crisp without restarting endlessly)
      let resizeTimer;
      window.addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(() => {
          cancelAnimationFrame(rafId);
          startTime = null;
          rafId = requestAnimationFrame(render);
        }, 250);
      });
    }
  }

  /* ============================================
     SCROLL REVEAL FOR SECTIONS
     ============================================ */
  const revealTargets = document.querySelectorAll(
    '.about-inner, .menu-inner, .gallery-grid, .reviews-inner, .visit-inner'
  );

  if ('IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = 1;
          entry.target.style.transform = 'none';
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });

    revealTargets.forEach(el => {
      el.style.opacity = 0;
      el.style.transform = 'translateY(24px)';
      el.style.transition = 'opacity .6s ease, transform .6s ease';
      observer.observe(el);
    });
  }

});
